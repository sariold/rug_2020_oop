package nl.rug.oop.rpg;

public interface Interactable {

    void interact(Player player);
}
