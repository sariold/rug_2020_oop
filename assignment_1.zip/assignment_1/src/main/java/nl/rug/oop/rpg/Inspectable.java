package nl.rug.oop.rpg;

public interface Inspectable {

    void inspect();

}
